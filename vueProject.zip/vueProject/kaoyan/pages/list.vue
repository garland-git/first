<template>
  <div class="user-page">
    <list />
  </div>
</template>

<script>
import list from '@/components/List'
export default {
  components: {
    list
  },
  data () {
    return {}
  },
  computed: {},
  watch: {},
  created () {},
  methods: {}
}
</script>

<style lang='scss'></style>
