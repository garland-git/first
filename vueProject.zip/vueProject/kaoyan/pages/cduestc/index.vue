<template>
  <div id="cduestc-page" class="container">
    <people />
  </div>
</template>

<script>
import people from '@/components/cduestc/people'
export default {
  components: {
    people
  },
  data () {
    return {}
  },
  computed: {},
  watch: {},
  created () {},
  mounted () {},
  methods: {}
}
</script>

<style lang='scss'>
#cduestc-page {
  padding-top: 50px;
}
</style>
