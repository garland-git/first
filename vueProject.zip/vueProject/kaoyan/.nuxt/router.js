import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6e61e360 = () => interopDefault(import('..\\pages\\bbs\\index.vue' /* webpackChunkName: "pages/bbs/index" */))
const _cc3f12fc = () => interopDefault(import('..\\pages\\cduestc\\index.vue' /* webpackChunkName: "pages/cduestc/index" */))
const _4816b502 = () => interopDefault(import('..\\pages\\list.vue' /* webpackChunkName: "pages/list" */))
const _73925bcd = () => interopDefault(import('..\\pages\\school\\index.vue' /* webpackChunkName: "pages/school/index" */))
const _75fa2284 = () => interopDefault(import('..\\pages\\timu\\index.vue' /* webpackChunkName: "pages/timu/index" */))
const _65277b89 = () => interopDefault(import('..\\pages\\post\\_id.vue' /* webpackChunkName: "pages/post/_id" */))
const _83d6eb7e = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/bbs",
    component: _6e61e360,
    name: "bbs"
  }, {
    path: "/cduestc",
    component: _cc3f12fc,
    name: "cduestc"
  }, {
    path: "/list",
    component: _4816b502,
    name: "list"
  }, {
    path: "/school",
    component: _73925bcd,
    name: "school"
  }, {
    path: "/timu",
    component: _75fa2284,
    name: "timu"
  }, {
    path: "/post/:id?",
    component: _65277b89,
    name: "post-id"
  }, {
    path: "/",
    component: _83d6eb7e,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
